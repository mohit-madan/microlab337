# microlab337
We are designing a multi-cycle processor. Implementing it using VHDL. It is a 8- register 16 bit computer system which uses point to point communication infrastructure.
